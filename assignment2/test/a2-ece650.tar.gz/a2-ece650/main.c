//
// Created by mengdongqi on 15-10-24.
//

#include "base.h"

int main() {
    USER_INPUT user_input;
    read_and_handle_input(&user_input);
    return 0;
}

