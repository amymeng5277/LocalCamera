//
// Created by mengdongqi on 15-10-24.
//

#ifndef ASSIGNMENT2_UTIL_H
#define ASSIGNMENT2_UTIL_H

// get length of the string format of this num
int num_str_length(char *s, int num);


#endif //ASSIGNMENT2_UTIL_H
